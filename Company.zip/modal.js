var modal = document.getElementById("join");
var close = document.getElementById("push");

setTimeout (function (){
     modal.style.display = "block";

}, 3000)

push.onclick = function() {
   modal.style.display = "none";
   }
